const express =require('express');
const bodyparser =require('body-parser');

const nodemailer =require('nodemailer');

const app=express();
app.use(express.static("data"));
app.use(bodyparser.urlencoded({extended: true}))

app.get("/",function(req,res){
    res.sendFile(__dirname + "/index.html");
    console.log(__dirname);
})

app.post("/", function(req, res){
    const comm = req.body.message;
    const na = req.body.nameofperson;
    var transporter = nodemailer.createTransport({
        service : 'gmail',
        auth:{
            user:'sutarprasad454@gmail.com',
            pass:'pvhxzqcntejrshlw'
        }
    })
    var mailOption={
        from:'sutarprasad454@gmail.com',
        to:req.body.username,
        cc:'sutarprasad454@gmail.com',
        subject:'thanks for visit delhi pizza' +na,
        text:'thanks for your message you have sent us' + comm
    } ;
   transporter.sendMail(mailOption,function(error,info){
    if(error){
        console.log(error)
    }else{
        res.redirect('/');
        console.log("email sent" + info.response);
    }

   }) 
  
});
app.listen(2020,function(){
    console.log("server started at 2020");
})
